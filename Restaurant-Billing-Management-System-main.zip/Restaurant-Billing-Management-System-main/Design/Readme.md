## Prerequisites

1. Class Diagram : https://www.youtube.com/watch?v=UI6lqHOVHic
2. Sequence Diagram : https://www.youtube.com/watch?v=pCK6prSq8aw

## Other References

1. https://www.visual-paradigm.com/guide/uml-unified-modeling-language/what-is-classdiagram/
2. https://www.tutorialspoint.com/uml/uml_class_diagram.htm
3. https://en.wikipedia.org/wiki/Sequence_diagram
4. https://www.tutorialspoint.com/uml/uml_activity_diagram.htm
