## SRS

1. What should a good SRS have ? https://ieeexplore.ieee.org/document/278253
