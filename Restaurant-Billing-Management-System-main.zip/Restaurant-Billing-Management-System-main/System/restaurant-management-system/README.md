## Restaurant-Billing-Management-System

SRS, Design is already provided. 

Run in Terminal : java -jar RestaurantSystem.jar

Name : Bhukya Vasanth Kumar
Roll : B180441CS
A - Batch, Sem 7, CSE
